/*
	Created By: Pravin Kardile
	Created Date: 19-Jun-2018
	Description: This file has been created for 'Intent Engine Call for Dialog Flow' module.
*/
var dialogFlowAPI = require('apiai');
var rp = require('request-promise');
var callRestApi = require('../models/rest-apis');
var fs = require('fs');
var constants = require('../utilities/constants');
var utilities = require('../utilities/utilities');
var configProvider = require('../providers/config-provider');
var logger = require('../utilities/logger.js');
var log = logger.getLogger("intent-engine-dialog-flow");
var serverURL = "";

var intEngCallDialogFlowMod = {
    //function to initialize the dialog flow Node JS client
    Init: function(url) {
        serverURL = url;
    },
    //function to send request to dialog flow
    SendRequest: function(data, sessionId, username, fromOrcFlag, from_orc, orc_error, callback) {
        console.log("from_orc",from_orc);
		var contextId = sessionId || 0;
		var input_code = "R";
		if(!fromOrcFlag){
			from_orc = "0";
		}else{
			input_code = "OQS";
			if(orc_error){
				input_code = "OQF";
			}
			from_orc = "'"+from_orc+"'";
		}
		
		var queryString = {
			input_text: data,
			context_id: contextId,
			input_code: input_code,
			from_orc: from_orc		
		};
		log.info("User	",username,"	 Backend process: in send request to intent engine - "+ JSON.stringify(queryString));
		/*var queryString = {};
		serverURL = serverURL+"?input_text="+data+"&context_id="+contextId+"&input_code="+input_code+"&from_orc="+from_orc;
		*/
		console.log("qs@@@@@",queryString);
		console.log("serverURL*****",serverURL)
		var options = utilities.getOptions(serverURL, queryString);
		rp(options).then(function(resp) {
			try{
				console.log("intent engine");
				console.log("******",resp);
				var outputResp = {};
				var resp_code = JSON.parse(resp.context_id);
				var best_intent = JSON.parse(resp.intent_id_best);
				if(best_intent){
					best_intent = best_intent[0];
				}else{
					best_intent = 0;
				}
				var conId = resp_code[0];
				console.log("Context id: "+conId);
				log.info("User	",username,"	 Backend process: in send request to intent engine - "+ JSON.stringify(resp));
				if(resp.output_code == "R"){
					outputResp = {
						sessionId: conId,
						outputText: resp.response,
						intentName: conId,
						intentBest: best_intent,
						outputCode: constants.DIRECTRESP
					};
					//Log missed utterances
					if(configProvider.Config["LogMissedUtterances"] && resp.response.indexOf("Sorry!!") == 0){
						utilities.writeMissedUtterToFile(data, username);
					}
				}else if(resp.output_code == "OQ" || resp.output_code == "OA" || resp.output_code == "XX"){
					outputResp = {
						sessionId: conId,
						outputText: resp.response,
						intentName: conId,
						intentBest: best_intent,
						outputCode: constants.ORACLECALL,
						parameters: resp.to_orc
					};
				}
				callback(outputResp);
			}catch(error){
				console.log("inside catch block intent engine call");
				log.error("User	",username,"	 Backend process: inside catch block intent engine call : error - "+ error);
				var outputResp = {
					outputText: error,
					outputCode: constants.OUTPUT_CODE_ERROR
				};
				callback(outputResp);				           
			}
		}).catch((err) => {
			console.log("inside catch block of send request RP");
			log.error("User	",username,"	 Backend process: inside catch block of send request RP : error - "+ err);
			var outputResp = {
				outputText: err,
				outputCode: constants.OUTPUT_CODE_ERROR
			};
			callback(outputResp);
			console.log("error");
			console.log(err); 
		});       
    },
    parseResponse: function(response, username, callback) {
		
		var outputCode = response.outputCode;
		var fulfilmentText= response.outputText;
		var opText=[];
		log.info("User	",username,"	 Backend process: in parse response fn - "+ JSON.stringify(response));
		switch(outputCode){
			case constants.DIRECTRESP:
			case constants.INPUTREQUIRED:
				var respData = {};
				var suggestions = configProvider.getIntentAction("suggestions");				
				if(suggestions && suggestions[response.intentBest]){
					respData = {"suggestions":suggestions[response.intentBest]};
				}

				var images = configProvider.getIntentAction("images");
				if(images && images[response.intentBest]){
					respData["imagesData"] = images[response.intentBest];
				}

				var links = configProvider.getIntentAction("links");
				if(links && links[response.intentBest]){
					respData["linksData"] = links[response.intentBest];
				}
				callback(response.outputText,response.sessionId,respData);
				break;
			// Case to make an Oracle call
			case constants.ORACLECALL:
				//var intentActions = JSON.parse(fs.readFileSync('./config/intent-actions.json', 'utf8'));
				var currentIntent = configProvider.getIntentAction(response.intentName);				
				log.info("User	",username,"	 Backend process: before REST API call");
				callRestApi.CallRESTAPI(response.sessionId, response.parameters,response.intentName, currentIntent,fulfilmentText, username, function(resp){
					/*if(resp.responseType == constants.RESPONSE_CSV){
						callback(resp.outputText,response.sessionId,resp.responseType, resp.CSVData,resp.linkedOrder);
					}else{
						callback(resp.outputText,response.sessionId);
					}*/
					log.info("User	",username,"	 Backend process: in REST API callback fn - "+JSON.stringify(resp));
					var orcError = false;
					var fromOrc = "0";
					var inputText = "valueprovided";
					var respData = {};
//console.log("^^^^^^^^^^^^^^",resp);
					if(resp.outputText == constants.OUTPUT_TEXT_ERROR){
						inputText = "orcerror";
						orcError = true;
						var errMsg = resp.errorMessage || currentIntent.orc_error;
						fromOrc = '{\\"orc_error\\":\\"'+errMsg+'\\"}';
						if(currentIntent.suggestions && currentIntent.suggestions.error){
							respData = {"suggestions":currentIntent.suggestions.error};
						}						
					}else{
						if(currentIntent.isfrom_orcField){
							fromOrc = '{\\"'+currentIntent.from_orc+'\\":\\"'+resp.outputText+'\\"}';
						}
						if(currentIntent.suggestions && currentIntent.suggestions.success){
							respData = {"suggestions":currentIntent.suggestions.success};
						}
					}
					if(resp.inputText){
						inputText = resp.inputText;
					}
					log.info("User	",username,"	 Backend process: send REST API result to intent engine");
					intEngCallDialogFlowMod.SendRequest(inputText, response.sessionId, username, true,fromOrc, orcError, function(intentEngineResp) {
						console.log("orc callback controller",intentEngineResp.outputText,"------",response.outputText,"*****",resp.outputText);	
						
						log.info("User	",username,"	 Backend process: in SendRequest callback of REST API");	
						var suggestions = configProvider.getIntentAction("suggestions");
						if(suggestions && suggestions[intentEngineResp.intentBest]){
							//respData = {"suggestions":suggestions[intentEngineResp.intentBest]};
							respData["suggestions"] = respData["suggestions"]? respData["suggestions"].concat(suggestions[intentEngineResp.intentBest]):suggestions[intentEngineResp.intentBest];	
						}	
						var images = configProvider.getIntentAction("images");
						if(images && images[intentEngineResp.intentBest]){
							respData["imagesData"] = images[intentEngineResp.intentBest];
						}

						var links = configProvider.getIntentAction("links");
						if(links && links[intentEngineResp.intentBest]){
							respData["linksData"] = links[intentEngineResp.intentBest];
						}			
						if(resp.responseType == constants.RESPONSE_CSV){
							respData["exportData"] = resp.CSVData;
							//callback(intentEngineResp.outputText,intentEngineResp.sessionId, respData, true, resp.responseType);
						}else if(resp.responseType == constants.RESPONSE_POPUP){
							respData["popupData"] = resp.popupData;
						}else if(resp.responseType == constants.FILEDOWNLOAD){
							respData["fileName"] = resp.fileName;							
						}
						
						respData["linksData"] = respData["linksData"]? respData["linksData"].concat(resp.linksData?resp.linksData:[]):resp.linksData;	
						respData["imagesData"] = respData["imagesData"]? respData["imagesData"].concat(resp.imagesData? resp.imagesData: []) : resp.imagesData;
						callback(resp.outputText,intentEngineResp.sessionId, respData, true, resp.responseType);
					});
				}); //pass the parameters
				
				break;
			case constants.OUTPUT_CODE_ERROR:
				callback(constants.CONNECTION_ERROR);
				break;
			default:				
				//var intentName = response.result.metadata.intentName;
				//check intent action
				break;
        }
        
    }
	
};

module.exports = intEngCallDialogFlowMod;