/*
	Created By: Pravin Kardile
	Created Date: 19-Jun-2018
	Description: This file has been created for 'Call REST API' module.
*/
const Json2csvParser = require('json2csv').Parser;
var rp = require('request-promise');
var utilities = require('../utilities/utilities');
var constants = require('../utilities/constants');
var configProvider = require('../providers/config-provider');
var logger = require('../utilities/logger.js');
var log = logger.getLogger("rest-api");

var RESTAPIMod = {
    //function to check the intent engine in config.json and initilize it.	
    CallRESTAPI: function(sessionId, parameters,intentName, intentAction,fulfilmentText, username, callback){
		log.info("User	",username,"	 Backend process: in CallRESTAPI fn");
		var inputs = intentAction.inputs;
		var IntentCode1 = intentName;
		console.log("parameters");
		console.log(parameters);
		var poNumber=parameters.entponum;
		console.log("/********",poNumber);
		var queryString = {};
		
		for(var inp in inputs){			
			if(inputs.hasOwnProperty(inp)){
				if(parameters[inputs[inp]]){
					queryString[inp] = parameters[inputs[inp]];
				}else{
					queryString[inp] = inputs[inp];
				}
			}
		}
		console.log("query String",queryString);
		if(intentAction.outputType == constants.FILEDOWNLOAD){
			RESTAPIMod.DownloadFile(queryString, username, callback);
		}else{
			var uri = intentAction.URI;
			if (uri) {
				//make REST API call using request-promise
				var options = utilities.getOptions(uri, queryString, intentAction.method);
				log.info("User	",username,"	 Backend process: in CallRESTAPI fn REST URL options:"+JSON.stringify(options));
				rp(options).then(function(resp) {
					try{
						log.info("User	",username,"	 Backend process: in CallRESTAPI fn REST API result:"+JSON.stringify(resp));
						console.log(" REST API call");
						
						console.log("Response details*****",resp);
						
						var respdetails=resp;
						
						var outResp = {outputText:""};
						var result = true;
						var outputs = intentAction.outputs;
						var outputMsg = "";
						var dataNew="";
						var dataLink="";
						if(outputs){
							for(var opt in outputs){			
								if(outputs.hasOwnProperty(opt) && outputs[opt] == resp[opt]){
									result = false;
									break;
								}else{
									outputMsg = resp[opt]
								}
							}
						}
						
						if(result){
							if(intentAction.outputMsgProp){
								outResp.outputText = resp[intentAction.outputMsgProp] || outputMsg;
							}else{
								outResp.outputText = outputMsg;
							}
						}else{
							outResp.outputText = constants.OUTPUT_TEXT_ERROR;						 	
							if(intentAction.outputMsgProp){
								outResp.errorMessage = resp[intentAction.outputMsgProp];
							}				
						}				

						switch(intentAction.outputType){
							case constants.RESPONSE_EXPORT:
								var json2csvParser = new Json2csvParser({header:true});//to remove the first line header part of csv data
								var expData = resp[intentAction.exportDataProp] || resp.exportedOrders;
								var orderDetails = json2csvParser.parse(expData);
								outResp = {
									outputText : constants.DOWNLOAD_CSV_MSG,
									responseType: constants.RESPONSE_CSV,
									CSVData: orderDetails
								};
								break;
							case constants.RESPONSE_POPUP:
								outResp.responseType = constants.RESPONSE_POPUP;
								outResp.popupData = resp[intentAction.popupDataProp] || resp.orderDetails;
								break;
								
							default:
								if(intentAction.outputType){
									outResp = {
										linksData : respdetails,
									outputText : "Search results are displayed below. Please click to open the link!!"
								};
								
						}	
						}	
						
						//to display links
						//outResp.linksData = (intentAction.linksDataProp)? resp : null;
						
						if(intentAction.linksData && intentAction.linksData.length > 0){
							outResp.linksData = outResp.linksData || [];
							outResp.linksData = outResp.linksData.concat(intentAction.linksData);
						}
						//to display images
						outResp.imagesData = (intentAction.imagesDataProp)? resp[intentAction.imagesDataProp] : null;
						if(result && intentAction.imagesData && intentAction.imagesData.length > 0){
							outResp.imagesData = outResp.imagesData || [];
							outResp.imagesData = outResp.imagesData.concat(intentAction.imagesData);
						}
						//to send custom message to intent engine
						if(intentAction.orcRespToIEProp){
							outResp.inputText = resp[intentAction.orcRespToIEProp];
						}
						
						callback(outResp);					
					}catch(error){
						console.log("inside catch block rest api");
						var outResp = {
							outputText : constants.OUTPUT_TEXT_ERROR
						};
						log.error("User	",username,"	 Backend process: in CallRESTAPI fn catch block: "+error);
						callback(outResp);
						console.log("error");
						console.log(error); 
								
					}
				}).catch((err) => {
					console.log("inside catch block rest api RP");
					var outResp = {
						outputText : constants.OUTPUT_TEXT_ERROR,
						errorMessage: constants.CONNECTION_ERROR
					};
					log.error("User	",username,"	 Backend process: in CallRESTAPI fn RP catch block: "+err+" Parameters:"+JSON.stringify(options)); 
					callback(outResp);
					console.log("error");
					console.log(err);				 
				});
			}else{	
				if(intentAction.outputType == constants.RESPONSE_LINKS){
					var outResp = {	outputText:constants.SUCCESS,
						responseType: constants.RESPONSE_LINKS,
						linksData:[]
					};
					log.info("User	",username,"	 Display links");
					if(intentAction.linksData && intentAction.linksData.length > 0){
						outResp.linksData = intentAction.linksData;
					}else{
						outResp.outputText = constants.OUTPUT_TEXT_ERROR;
						outResp.responseType = "";
					}
					callback(outResp);
				}else{
					var outResp = {
						outputText : constants.OUTPUT_TEXT_ERROR
					};
					log.error("User	",username,"	 Backend process: in CallRESTAPI fn REST API URL is not defined");  
					callback(outResp);
				}			
			}
		}
	},
	DownloadFile: function(parameters, username, callback){
		var filePath = configProvider.Config["DefaultDownloadPath"]+"/"+parameters["FileName"];
		var outResp = {};
        if(utilities.fileExists(filePath)){
			outResp.outputText = "File is present";
			outResp.responseType = constants.FILEDOWNLOAD;
			outResp.fileName = parameters["FileName"];
        }else{
			outResp.outputText = constants.OUTPUT_TEXT_ERROR
			log.error("User	",username,"	 Backend process: in Download fn, file not found");			
		}  
		callback(outResp);
	}
};


module.exports = RESTAPIMod;