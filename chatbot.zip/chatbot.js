var ChatBotClientApp = ChatBotClientApp || {}; 
function inIframe(){
	try {
		return window.self !== window.top;
	} catch (e) {
		return true;
	}
}
function getUser(){
	var userName = "";
	var userStr = document.location.search;                                                
	if(userStr){
		userStr = userStr.replace("?","");
		userStr = userStr.split("=");
		if(userStr.length>1 && userStr[0] == "user"){
						userName = userStr[1];
		}
	}
	return userName;
}
  
function clickOnLink(linkVal, level){
	if(level != 1){
		$('#txtsendtext').val(linkVal);
		$('#chatform').submit();
	}else{
		var welcomeOptions = ChatBotClientApp.ChatWindow.configData.WelcomeOptions;
		if(welcomeOptions){
			var buttons = welcomeOptions[linkVal].buttons;
			var tooltip = welcomeOptions[linkVal].tooltipText;
			if(welcomeOptions[linkVal].notConfigured){
				//$('.chat-history .chat-message .chat-message-content .welcome-msg-options .msg-text').html(welcomeOptions[linkVal].tooltipText);
				//$('.chat-history .chat-message .chat-message-content .welcome-msg-options').show();
			}else if(buttons.length > 0){
				$('.chat-history .chat-message .chat-message-content .welcome-msg-options .msg-text').html(welcomeOptions[linkVal].btnText);				
				for(var btn in buttons){
					if(buttons.hasOwnProperty(btn)){
						$('.chat-history .chat-message .chat-message-content .welcome-msg-options ul').append($('<li class="chat-list-item"><a href="javascript:clickOnLink(\''+buttons[btn]+'\',2)" class="chat-list-link">'+buttons[btn]+'</a></li>'));
					}
				}
				$('.chat-history .chat-message .chat-message-content .welcome-msg-options').show();
			}else{
				$('#txtsendtext').val(linkVal);
				$('#chatform').submit();
			}
		}
	}
	$(".chat-history").animate({ scrollTop: ($(".chat-message.clearfix").height()+60) }, 100);
}									 

if (typeof(ChatBotClientApp.ChatWindow) === "undefined"){
	
	ChatBotClientApp.ChatWindow = (function(){
		
		function ChatWindow()
		{
			this.readResponse = false;
			this.isAudioInput = false;
			this.sessionId = "";
			this.timer= null;
			this.user = "";
			this.configData = {};			
			
			this.GetConfigData();			
		}
		
		//function for audio output
		ChatWindow.prototype.Speech = function(say,isAudioInput){
			if ('speechSynthesis' in window && (this.readResponse || this.isAudioInput)) {				
				if(say){
					var synth = window.speechSynthesis;
					var text = $('<div></div>').html(say).text().trim();
					//var voices = synth.getVoices();
					var utterance = new SpeechSynthesisUtterance(text);
					//utterance.voice = voices[8];
					speechSynthesis.speak(utterance);
				}
			}
		};
		
		ChatWindow.prototype.GetConfigData = function(){
			$.ajax({
				url: "ui-config.json",
				type: "GET",
				async:false,
				timeout: 30000,
				dataType: "json", // "xml", "json"
				contentType: "application/json",
				context: this,
				success: function(data) {
					if(data){
						this.configData = data;
						console.log(this.configData);
						this.UpdateUI();
					}
				},
				error: function(jqXHR, textStatus, ex) {
					console.log("error: "+textStatus);                                                             
				}
			});
		};
		ChatWindow.prototype.UpdateUI = function(){
			
			if((!$("#live-chat").hasClass("full-screen") && this.configData.ChatIcon) || inIframe()){
				$('#live-chat').addClass("with-chat-icon");
				$('#live-chat').removeClass("on");
			}
			//Check if speech recognition is supported or not
			if(!('webkitSpeechRecognition' in window)){
				console.log("speech recognition is not supported");
				$('#live-chat .fa.fa-microphone').addClass("disabled").attr("title","Speech recognition is not supported by your browser");
			}
			//Add FAQs
			var faqs = this.configData.FAQs;
			if(faqs){
				$('#live-chat .frequentQueries .freqQueryPopup ul').html('');
				for(var faq in faqs){
					if(faqs.hasOwnProperty(faq)){
						$('#live-chat .frequentQueries .freqQueryPopup ul').append($('<li><span class="fa fa-angle-right"></span><span class="link">'+faqs[faq]+'</span></li>'));
					}
				}			
			}
			//welcome message
			var welcomeMessage = this.configData.WelcomeMessage;
			if(welcomeMessage.image){				
				$('.chat-history .chat-message .chat-message-content .welcome-msg .welcome-img').append($('<img src="./images/'+welcomeMessage.image+'">'));
			}
			if(welcomeMessage.text){				
				$('.chat-history .chat-message .chat-message-content .welcome-msg .welcome-text').show().append($('<span>'+welcomeMessage.text+'</span>'));
			}
			var welcomeOptions = welcomeMessage.options;
			if(welcomeOptions){
				for(var opt in welcomeOptions){
					if(welcomeOptions.hasOwnProperty(opt)){						
						$('.chat-history .chat-message .chat-message-content .welcome-msg .welcome-options').append($('<a href="javascript:clickOnLink(\''+welcomeOptions[opt]+'\')" >'+welcomeOptions[opt]+'</a>'));
					}
				}
			}			
		/*	var welcomeOptions = this.configData.WelcomeOptions;
			if(welcomeOptions){
				for(var opt in welcomeOptions){
					if(welcomeOptions.hasOwnProperty(opt)){
						var tooltip = welcomeOptions[opt].tooltipText;
						var tooltipHtml = "";
						if(tooltip){
							tooltipHtml = '<span class="tooltiptext">'+tooltip+'</span>'
						}
						$('.chat-history .chat-message .chat-message-content .welcome-msg ul').append($('<li class="chat-list-item '+( tooltip? "tooltip":"")+'" ><a href="javascript:clickOnLink(\''+opt+'\',1)" class="chat-list-link" >'+welcomeOptions[opt].displayValue+'</a>'+tooltipHtml+'</li>'));
					}
				}
			}*/	
			this.SendUpdatetoServer(this.user,"init");		
		};
	//function to add events to Chat UI
		ChatWindow.prototype.AddEvents = function(){			
			if(inIframe()){
				this.user = getUser();
				console.log("Username="+this.user);
				$('html').addClass("chatbot-in-iframe");
			}
			var _this = this;
			_this.isLoaded = _this.isLoaded || false;	
			//minimize chat window on click of header
			$('#live-chat header').off('click').on('click',{ctx:this},function(e) {
				if(!$('#live-chat').hasClass('full-screen')){
					$('.chat').slideToggle(300, 'swing');
					$('#live-chat').toggleClass("on");
					if(inIframe()){
							//var height = $('#live-chat').hasClass('on')? 465 : (_this.configData.ChatIcon)?80:50;
							//var width = $('#live-chat').hasClass('on')? 360 : (_this.configData.ChatIcon)?80:360;
							var height = $('#live-chat').hasClass('on')? 465 : 80;
							var width = $('#live-chat').hasClass('on')? 365 : 80;
							window.parent.postMessage(["setHeight", height, width], "*");
						} 
					if($('#live-chat').hasClass('on')){
						setTimeout(function(){
							$('#txtsendtext').focus();
						},500);
					}
					if(!_this.isLoaded){
						var firstName = '';
						var defaultMessage = 'How can I help you today?'
						
						_this.isLoaded = true;
					}
					$(".chat-history").animate({ scrollTop: ($(".chat-message.clearfix").height()+60) }, 300);
				}
			});	
			
			//Close FAQ popup on click of icon
			$('#live-chat .frequentQueries>.link,#live-chat .frequentQueries .freqQueryPopup .closePopup').off('click').on('click', function() {
				$(this).parents('.frequentQueries').find('.freqQueryPopup').slideToggle(300, 'swing');
			});

			//Open FAQ popup on click of icon
			$('#live-chat .faq-icon').off('click').on('click', function(e) {
				$('#live-chat .frequentQueries .freqQueryPopup').slideToggle(300, 'swing');
				if($('#live-chat').hasClass('on')){
					e.preventDefault();
					e.stopPropagation();
				}
			});
			
			//Open skype on click of request advisor
			$('#live-chat .request-advisor').off('click').on('click',{ctx:this}, function(e) {
				if(e.data.ctx.configData.RequestAdvisorId){
					window.location = "sip:"+e.data.ctx.configData.RequestAdvisorId;
				}
				if($('#live-chat').hasClass('on')){
					e.preventDefault();
					e.stopPropagation();
				}
			});
			
			//clear window
			$('#live-chat .clear-icon').off('click').on('click', {ctx:this}, function(e) {
				$('#live-chat .chat-message .message-box-wrapper-user,#live-chat .chat-message .message-box-wrapper-bot').remove();
				//_this.UpdateUI();
				_this.sessionId = "";
				$('#live-chat .suggestions').html('');
				$('#txtsendtext').val('');
				sessionStorage.clear();
				e.preventDefault();
				e.stopPropagation();
			});

			//Enable disable audio output
			$('#live-chat .volume-icon').off('click').on('click', {ctx:this}, function(e) {
				$(this).toggleClass('fa-volume-off').toggleClass('fa-volume-up');				
				_this.readResponse = $(this).hasClass("fa-volume-up")? true : false;			
				e.preventDefault();
				e.stopPropagation();
			});
			//Show and hide confirmation message when user clicks on close icon.
			$('#live-chat #close-button').off('click').on('click', {ctx:this}, function(e) {
				$('#modal').addClass("visiblediv").removeClass("modal-box"); 
				$('#chat-history').css("overflow","hidden");
				$('#panel-footer').hide(); 		
				e.preventDefault();
				e.stopPropagation();
			});
			
			//Fire query on click of frequent queries
			$('#live-chat .frequentQueries .freqQueryPopup').delegate(".link",'click',{ctx:this}, function(event) {
				var query = $(this).text();
				$('#txtsendtext').val(query);
				$('#chatform').submit();
				$(this).parents('.freqQueryPopup').slideToggle(300, 'swing');
			});
			
			/*
			// Show Normal Order and linked order options on click of Order management
			$('#live-chat #orderManagement').off('click').on('click',{ctx:this}, function(event) {
				$('#order-types').css("display","block");
				document.getElementById("order-types").scrollIntoView();
			});
			// Fire query on click of Normal Order or Linked Order
			$('#live-chat #order-types .chat-list-wrapper .chat-list-item .chat-list-link ').off('click').on('click',{ctx:this}, function(event) {
				var query = $(this).text();
				$('#txtsendtext').val(query);
				$('#chatform').submit();
				$(this).parents('.freqQueryPopup').slideToggle(300, 'swing');
			});*/
			//On click of mic icon start audio recorder
			$('#live-chat .fa.fa-microphone').off('click').on('click',function(){
				if( !$(this).hasClass("disabled") && !$(this).hasClass("active")){
					$(this).toggleClass("active").toggleClass("listening");			
					$('#live-chat .chat-feedback').text("Listening...").show();
					_this.StartAudioRecorder();
				}					
			});

			$( "#txtsendtext" ).autocomplete({
				source: _this.configData.AutocompleteSearch,
				minLength: 3,
				autoFocus: true,
				position: { my : "left bottom", at: "left-5 top-12"},
				select: function( event, ui ) {
					$('#txtsendtext').val(ui.item.label);
					$('#chatform').submit();
					return false;
				}
			});

			//send request on click of send button or enter key press
			$('#chatform').on("submit", function(){
				_this.SendRequest();
				return false;
			});

			//to attach file on click of attach button
			$('#uploadFiles').on("click", function(){				
				_this.ShowMessage("Please select a file to upload", "response");	
				setTimeout(function(){
					console.log("upload");
					$('#uploadFilesDiv input[name="sampleFile"]').trigger("click");
				},0);			
			});
			$('#uploadFilesDiv input[name="sampleFile"]').on("change", function(){
				if($(this)[0].files[0]){
					console.log("FileName:"+$(this)[0].files[0].name);				
					_this.UploadFilesToServer();
				}
			});

			//image navigation buttons event
			$('#live-chat .chat .chat-history').delegate(".left-next-img","click",function(){
				console.log("clicked left key");
				var currentImg = $(this).closest(".message-images").find('.msg-img:visible').attr("data-count");
				if(currentImg > 0){
					var prevImg = parseInt(currentImg) - 1;
					$(this).closest(".message-images").find('.msg-img').eq(currentImg).toggle("slide", { direction: "right" }, 1000);
					$(this).closest(".message-images").find('.msg-img').eq(prevImg).toggle("slide", { direction: "left" }, 1000);
				}
			});
			$('#live-chat .chat .chat-history').delegate(".right-next-img","click",function(){
				console.log("clicked right key");
				var totalImages = $(this).closest(".message-images").attr("data-count");
				totalImages--;				
				var currentImg = $(this).closest(".message-images").find('.msg-img:visible').attr("data-count");
				if(currentImg < totalImages){
					var nextImg = parseInt(currentImg) + 1;
					$(this).closest(".message-images").find('.msg-img').eq(currentImg).toggle("slide", { direction: "left" }, 1000);
					$(this).closest(".message-images").find('.msg-img').eq(nextImg).toggle("slide", { direction: "right" }, 1000);
				}
			});
		};
		
		//function to start audio recorder
		ChatWindow.prototype.StartAudioRecorder = function(){
			if('webkitSpeechRecognition' in window){
				var transcript = "";
				var recognition = new webkitSpeechRecognition();
				var _this = this;
				
				recognition.lang="en-IN";//lang="en-GB";
				recognition.onresult = function(event){					
					//btn.toggleClass("active");
					transcript = event.results[0][0].transcript;

					var value = $("#txtsendtext").val();					
					var transcript1 = value + " " + transcript;
					$("#txtsendtext").val(transcript1);
					_this.isAudioInput = true;
					_this.SendRequest();
				};
				recognition.onerror = function(event) {
					console.log(event.error);
					var message = "";
					
					if("not-allowed" == event.error){
						message = "Microphone has been blocked for this page or it is not present, please contact your system administrator.";
					}else if("no-speech" == event.error){
						message = "No speech has been received, please try again";
					}
					_this.isAudioInput = true;
					_this.ShowMessage(message, "response");
					_this.isAudioInput = false;
				};
				recognition.onend = function(event) {					
					$('#live-chat .fa.fa-microphone').toggleClass("active").toggleClass("listening");
					//console.log("end");
					$('#live-chat .chat-feedback').hide();
				};
				
				recognition.start();
			}	
		};
		
		//function to show message in Chat UI		
		ChatWindow.prototype.ShowMessage = function(msg,type){
			var date = new Date();
			var time = date.toLocaleTimeString();
			var userText = ' user">';
			var chtabotText = ' chat-bot"><span class="user-icon"></span>';
			msg = msg.replace(/\\n/g,"<br/>");
			var chatmessage = '<div class="message-box-wrapper-'+((type == "request")? "user": "bot")+'"><div class="message-box'+((type == "request")? userText: chtabotText)+
			'<p>'+ msg + '</p><div class="time-container"><span class="chat-time">'+ time + '</div></span></div></div>';
			$(".chat-message.clearfix").append(chatmessage);
			$(".chat-history").animate({ scrollTop: ($(".chat-message.clearfix").height()+60) }, 100);
			
			if(type == "response"){
				$(".chat-feedback").hide();
				this.Speech(msg);
			}
		};
		ChatWindow.prototype.SetTimer = function(){
			this.ClearTimer();
			var _this = this;
			this.timer = setTimeout(function()
			{
				_this.ChatExitConfirmation();
				},120000);
		};
		ChatWindow.prototype.ClearTimer = function(){
			if(this.timer){
			clearTimeout(this.timer);
			}
		};
		ChatWindow.prototype.EventLogger = function(user, msg, action){
			$.ajax({
				type: "POST", 
				url: "api/logger",
				data: { Action: (action? action : "buttonClick"), Message:msg, User:user},
				dataType: "json",
			});
		};
		ChatWindow.prototype.SendUpdatetoServer = function(user, action){
			$.ajax({
				type: "POST", 
				url: "api/chatbot-"+action,
				data: { user:user},
				dataType: "json",
			});
		};
		//Show and hide confirmation message when user timeout occurs.
		ChatWindow.prototype.ChatExitConfirmation = function() {
			$('#timeout-modal').addClass("visiblediv").removeClass("timeout-modal-box"); 
			$('#chat-history').css("overflow","hidden");
			$('#panel-footer').hide(); 	
		};
		//function to send request to server
		ChatWindow.prototype.SendRequest = function(){
			
			var _this = this;
			var userInput = $('#txtsendtext').val();
			userInput = userInput? userInput.trim() : userInput;
			if(userInput){				
				_this.ShowMessage(userInput, "request");
				this.TypingAnimation(true);
				$.ajax({
					type: "POST",
					url: "api/chatbot-request",
					data: {inputText:userInput,sessionId:_this.sessionId, user:_this.user},
					success: function(resp){
						console.log("Success");
						console.log(resp);
						_this.TypingAnimation(false);
						if(resp.outputCode == "Success"){
							/*if(resp.respType == "user-input"){
								_this.SetTimer();
							}else 
							{
								_this.ClearTimer();
							}*/	
							console.log(resp.outputText);
							console.log(typeof resp.outputText);
							if(typeof resp.outputText === "object" && resp.outputText.length>1){
								for(var msg in resp.outputText){
									if(resp.outputText.hasOwnProperty(msg)){
										_this.ShowMessage(resp.outputText[msg], "response");
									}
								}
							}else{
								_this.ShowMessage(resp.outputText, "response");
							}						
							
							_this.sessionId = resp.sessionId;
							if(resp.respType == "CSV"){
								_this.ExportTOCSV(resp.data.exportData);
							}else if(resp.respType == "POPUP"){
								_this.DisplayPopup(resp.data.popupData);
							}else if(resp.respType == "FileDownload"){
								window.open('api/chatbot-download?file='+resp.data.fileName,"_blank");
							}						
							_this.CheckResponseData(resp.data);
						}
					},
					error:function(error){
						console.log("Error");
						console.log(error);
						_this.TypingAnimation(false);
						_this.ShowMessage("Error in connecting to Chatbot server, please try again later", "response");
					}
				});
			}	
			$('#txtsendtext').val("");
		};
		ChatWindow.prototype.UploadFilesToServer = function(){			
			$('#uploadFilesDiv input[name="sessionId"]').val(this.sessionId);
			$('#uploadFilesDiv input[name="user"]').val(this.user);
			$('#uploadFilesDiv input[name="inputText"]').val("File upload using button");
			var fileName = $('#uploadFilesDiv input[name="sampleFile"]')[0].files[0].name;
			var data = new FormData($("#uploadFilesDiv form[name='uploadFilesForm']")[0]);
			
			this.ShowMessage("File selected for upload: "+fileName, "request");
			$('.chat-feedback').text("Uploading file...").show();
			
			$.ajax({
				type: "POST",
				enctype: 'multipart/form-data',
				url: "api/chatbot-upload-files",
				data: data,
				cache: false,
				processData: false,
				contentType: false,
				context: this,
				success: function(resp){
					console.log("Success");
					$('.chat-feedback').hide();
					console.log(resp);
					if(resp.outputCode == "Success"){
						
						console.log(resp.outputText);
						console.log(typeof resp.outputText);
						if(typeof resp.outputText === "object" && resp.outputText.length>1){
							for(var msg in resp.outputText){
								if(resp.outputText.hasOwnProperty(msg)){
									this.ShowMessage(resp.outputText[msg], "response");
								}
							}
						}else{
							this.ShowMessage(resp.outputText, "response");
						}						
						
						this.sessionId = resp.sessionId;
						if(resp.respType == "CSV"){
							this.ExportTOCSV(resp.data.exportData);
						}else if(resp.respType == "POPUP"){
							this.DisplayPopup(resp.data.popupData);
						}else if(resp.respType == "FileDownload"){
							window.open('api/chatbot-download?file='+resp.data.fileName,"_blank");
						}
						this.CheckResponseData(resp.data);
					}
					$("#uploadFilesDiv form[name='uploadFilesForm']")[0].reset();
				},
				error:function(error){
					console.log("Error");
					console.log(error);
					$("#uploadFilesDiv form[name='uploadFilesForm']")[0].reset();
				}
			});
		};
		
		ChatWindow.prototype.CheckResponseData = function(data){
			$('#live-chat .suggestions').html('');
			if(data && data.imagesData && data.imagesData.length>0){
				this.AddImagesToBotMessage(data.imagesData);
			}
			if(data && data.linksData && data.linksData.length>0){
				this.AddLinksToBotMessage(data.linksData);
			}
			if(data && data.suggestions && data.suggestions.length > 0){
				setTimeout(function(){
					$('#live-chat .suggestions').html('Suggessions: ');
					for(var btn in data.suggestions){
						if(data.suggestions.hasOwnProperty(btn)){						
							$('#live-chat .suggestions').append($('<a href="javascript:clickOnLink(\''+data.suggestions[btn]+'\')" >'+data.suggestions[btn]+'</a>'));
						}
					}
					$(".chat-history").animate({ scrollTop: ($(".chat-message.clearfix").height()+60) }, 100);
				},500);
			}
		};

		ChatWindow.prototype.ExportTOCSV = function(content, file_name, buttonClick ){
			try{
				if(!buttonClick){
					this.AddButtonToBotMessage(content,"EXPORT");
				}
				//var filename = file_name || "OrderData";
				var filename = file_name || "Orders";				   
				try{
					var currentDate = new Date()
					filename += "_"+currentDate.format('ddmmmyyyyHHMMss').toUpperCase();
				}catch(err){
					//filename = "OrderData";
					filename = file_name || "Orders";	
				}
				var rows = content.split("\\n");
				filename = filename+".csv";
				var BOM = "\uFEFF";
				var csvData = BOM + rows.join('\n');
				var blob = new Blob([csvData],{type: 'text/csv;charset=utf-8'});
				
				if(navigator.msSaveBlob){
					navigator.msSaveBlob(blob,filename);
				}else{
					var link = document.createElement("a");
					if(link.download !== undefined){
						var url = URL.createObjectURL(blob);
						link.setAttribute("href",url);
						link.setAttribute("download",filename);
						link.style.visibility='hidden';
						document.body.appendChild(link);
						link.click();
						document.body.removeChild(link);
					}					
				}				
			}catch(error){
				SiebelJS.Log("Error:"+error);
			}
		};

		ChatWindow.prototype.DisplayPopup = function(data, buttonClick){
			if(!buttonClick){
				if(typeof data == "string")
					data = formatMessage(data);
				else{
					var formattedMsg = $("<div></div>");
					for(var prop in data){
						if(data.hasOwnProperty(prop)){
							formattedMsg.append($('<div class="propRow"><div class="propCol label">'+prop+'</div><div class="propCol">'+data[prop]+'</div></div>'));
						}
					}
					data = formattedMsg.html();
				}
				this.AddButtonToBotMessage(data,"POPUP");
			}

			if(inIframe()){
				console.log("inside iframe cond");
				window.parent.postMessage(["displayPopup", data], "*");
			}else{
				$('<div class="chatbot-popup">'+data+'</div>').dialog({
					/*width: 550,*/
					maxWidth: 500,
					minWidth: 350,
					maxHeight: 500,
					title: "Details",
					modal: true,
					buttons: {
						"OK":{
							click: function () {
								$(this).dialog("close");
							},
							text: 'OK'					
						}
					}
				});
			}
		};

		ChatWindow.prototype.AddButtonToBotMessage = function(data, type){			
			var fnNamesForType = {
				"POPUP":{"function":"displayPopupAgain","displayName":"Display Again"},
				"EXPORT":{"function":"exportDataAgain","displayName":"Download"},
			};
			var fnName = "clickOnLink";
			var displayName = data;
			var msgId = data;

			if(fnNamesForType[type]){
				fnName = fnNamesForType[type].function;
				displayName = fnNamesForType[type].displayName;
				msgId = "msg_"+new Date().getTime();
				sessionStorage.setItem(msgId, data);
			}

			$('#live-chat .chat-history .message-box.chat-bot:last .time-container')
			.before($('<div class="message-btn"><button onclick="'+fnName+'(\''+msgId+'\')">'+displayName+'</button></div>'));
		};

		ChatWindow.prototype.AddLinksToBotMessage = function(linksData){			
			var links = $('<div class="welcome-options"></div>');
			if(linksData && linksData.length > 0){
				for(var link in linksData){
					if(linksData.hasOwnProperty(link)){
						
						links.append("<div class='msg-link'><a href='"+linksData[link].globalAnswerId+"' target='_blank'>"+linksData[link].title+"</a></div>");
					}
				}
			}
			$('#live-chat .chat-history .message-box.chat-bot:last .time-container')
			.before(links);
		};

		ChatWindow.prototype.AddImagesToBotMessage = function(imagesData){			
			var images = $('<div class="message-images"></div>');
			if(imagesData && imagesData.length > 0){
				var imgCount = 0;
				for(var image in imagesData){
					if(imagesData.hasOwnProperty(image)){
						var caption = imagesData[image].caption? "<div class='img-caption'>"+imagesData[image].caption+"</div>" :"";
						images.append("<div class='msg-img' data-count='"+imgCount+"'><img src='images/"+imagesData[image].name+"' alt='"+imagesData[image].caption+"'>"+caption+"</div>");
						imgCount++;
					}
				}
				images.attr("data-count",imgCount).append($('<div class="left-next-img"><span class="fa fa-angle-left"></span></div><div class="right-next-img"><span class="fa fa-angle-right"></div>'));
				$('#live-chat .chat-history .message-box.chat-bot:last .time-container')
				.before(images);
				//.before($('<div class="message-images-wrapper"></div>').append(images));
				if(imgCount > 1){
					$('#live-chat .chat-history .message-box.chat-bot:last .right-next-img,#live-chat .chat-history .message-box.chat-bot:last .left-next-img').show();
				}
			}			
		};

		ChatWindow.prototype.TypingAnimation = function(flag){
			if(flag){
				$('#live-chat .chat-history .message-box-wrapper-bot.typing-loader-div').remove();
				var chatmessage = '<div class="message-box-wrapper-bot typing-loader-div"><div class="message-box  chat-bot"><span class="user-icon"></span>'+
				'<div class="typing-loader"></div></div></div>';
				$(".chat-message.clearfix").append(chatmessage);
				$(".chat-history").animate({ scrollTop: ($(".chat-message.clearfix").height()+60) }, 100);				
			}else{
				$('#live-chat .chat-history .message-box-wrapper-bot.typing-loader-div').remove();
			}
		};
		
		return new ChatWindow;
	}());	
}

$(document).ready(function(){
	ChatBotClientApp.ChatWindow.AddEvents();
	/*var response = "Hi, I am Ricoh Assistant. How can I help you?";
	ChatBotClientApp.ChatWindow.ShowMessage(response, "response");*/
});

function formatMessage(inputData){
	var result = "";
	inputData = inputData.replace(/\n/ig,"<br/>");
	var boldStrings = inputData.split("**");

	for(var i=0;i<boldStrings.length;i++){
		if(i%2 == 0){
			result += boldStrings[i];
		}else{
			result += "<b>"+boldStrings[i]+"</b>";
		}
	}
	return result;
}
function displayPopupAgain(messageId){
	//alert(messageId);
	var data = sessionStorage.getItem(messageId);
	ChatBotClientApp.ChatWindow.DisplayPopup(data, true);
}
function exportDataAgain(messageId){
	//alert(messageId);
	var data = sessionStorage.getItem(messageId);
	ChatBotClientApp.ChatWindow.ExportTOCSV(data,undefined, true);
}
function show() {
	console.log("Hi");
	document.getElementById('order-types').style.display='block'; 
	//document.getElementById('chat-history').style.overflow = 'hidden';
	//document.getElementById('panel-footer').style.display= 'none';
}
function closeWindow() {
	document.getElementById('live-chat').className = 'hiddendiv';
	ChatBotClientApp.ChatWindow.SendUpdatetoServer("","close")
}
function closemodal() {
	document.getElementById('modal').className = 'hiddendiv';
	document.getElementById('panel-footer').style.display= 'block';
	document.getElementById('chat-history').style.overflow = 'auto';
}
function closetimeoutmodal() {
	document.getElementById('timeout-modal').className = 'hiddendiv';
	document.getElementById('panel-footer').style.display= 'block';
	document.getElementById('chat-history').style.overflow = 'auto';
	ChatBotClientApp.ChatWindow.SetTimer();
}