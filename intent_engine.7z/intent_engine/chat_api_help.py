# coding: utf-8

# #### Chatbot Prediction Notebook

# In[158]:


import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import re
import pickle
import json
import spellchecker as spcor

# Data Loading


# In[159]:


# Input Parameters
threshold = 60  # Confidence threshold
unknown_intent = 99006  # Default intent id if confidence is low
spell_correct_flag = 1  # 1 to enable spell correct else 0
entity_mode = 'SQ'  # Sequence(SQ) or Any(ANY) #v1.6 entity sequence change

with open('chat_pkl.pkl', 'rb') as f:
    (utter_array, utterid_array, utterances, intents, vocab, vocab_to_int, vocab_size,
     stop_words, prerep_dict, postrep_dict, regexs) = pickle.load(f)


# Data Cleaning

# In[161]:


def replace_words(text, replace_dict):
    # In a text, replace 'from word' to 'to word' based on a dictionary
    '''
    param: text: text within which some words have to be replaced
    param: replace_dict: dictionary that has the from and to words
    return: text: text with words replaced
    '''
    for word, replacement in replace_dict.items():
        text = text.replace(word + ' ', replacement + ' ')
        if text.endswith(word):
            text = text.replace(word, replacement + ' ')
    return text


# In[162]:


replace_words('list of unapproved POs', prerep_dict)


# In[163]:


def text_transform(text):
    # Strip additional spaces and convert to lower case
    '''
    param:  text: input text in string format
    return: text: processed text
    '''
    text = text.lower()
    text = re.sub('\s+', ' ', text)
    return text


# In[164]:


def replace_entity(input_text, regexs, context_id):
    # Find entities like SO numbers in text and replace them by a standard text for recognition
    '''
    param:  input_text: input text in string format
    param: regexs: dataframe of regexs in the format intentid, regex
    param: context_id: The context intent id passed to the chat
    return: input_text: processed text
    '''
    if context_id in regexs['intent_id'].values:
        # print("yes")
        regdict = json.loads(regexs['regex'][regexs['intent_id'] == context_id].values[0])
        # Find matching entities and replace with words
        for regex, word in regdict.items():
            entity = re.findall(regex, input_text)
            for num in entity:
                input_text = input_text.replace(num, word)
    return input_text


def replace_entity_seq(input_text, regexs, context_id):
    # Find entities like SO numbers in text and replace them by a standard text for recognition
    '''
    param:  input_text: input text in string format
    param: regexs: dataframe of regexs in the format intentid, regex
    param: context_id: The context intent id passed to the chat
    return: input_text: processed text
    '''
    if context_id in regexs['intent_id'].values:
        reg = regexs['regex'][regexs['intent_id'] == context_id].values

        reglist = []
        for each_reg in reg:
            reglist += [each.split('=') for each in each_reg.split(';')]
        # print(reglist)

        # Find matching entities and replace with words

        for each in reglist:
            #print(each[0])

            entity = re.findall(each[0], input_text)
            # print('entity', entity, entity2, entity3)
            # print(each[0] == reg1 )
            #print(entity)
            num = entity[0] if len(entity) else 'unknown'
            word = each[1]
            #print('num, word', num, word)

            # input_text = input_text.replace( num, word)

            if len(entity):
                # print(len(entity))
                input_text = input_text.replace(num, word, 1)
            # else:
            #    input_text += 'unknown'
            # print('input text', input_text)

    return input_text


def find_entity(input_text, regexs, context_id):
    orcout_dict = {}
    # Find entities like SO numbers in text and return it as a dictionary e.g. {'entsonum': ['3110000']}
    '''
    param:  input_text: input text in string format
    param: regexs: dataframe of regexs in the format intentid, regex
    param: context_id: The context intent id passed to the chat
    return: orcout_dict: Return entity as a dictionary - entity: list of identified entity numbers
    '''
    if context_id in regexs['intent_id'].values:
        regdict = json.loads(regexs['regex'][regexs['intent_id'] == context_id].values[0])
        # Find matching entities and replace with words
        for regex, word in regdict.items():
            entity = re.findall(regex, input_text)
            # print(entity)
            for num in entity:
                input_text = input_text.replace(num, word)
            orcout_dict[word] = entity

    return orcout_dict


def find_entity_seq(input_text, regexs, context_id):
    orcout_dict = {}
    # Find entities like SO numbers in text and return it as a dictionary e.g. {'entsonum': ['3110000']}
    '''
    param:  input_text: input text in string format
    param: regexs: dataframe of regexs in the format intentid, regex
    param: context_id: The context intent id passed to the chat
    return: orcout_dict: Return entity as a dictionary - entity: list of identified entity numbers
    '''
    #print(context_id)
    if context_id in regexs['intent_id'].values:

        reg = regexs['regex'][regexs['intent_id'] == context_id].values[0]
        reglist = [each.split('=') for each in reg.split(';')]
        # print('reglist', reglist)
        # Find matching entities and replace with words
        for each in reglist:
            # print(each)
            entity = re.findall(each[0], input_text)
            # print('entity', entity)
            num = entity[0] if len(entity) else 'unknown'
            word = each[1]

            # for num in entity:
            # continue
            # input_text = input_text.replace( num, word)
            # print('entity 0', entity[0])
            # print('input text', input_text)
            # print('num word', num, word)
            input_text = input_text.replace(num, word, 1)
            # print('input text', input_text)

            orcout_dict[word] = num

        # print('orcout dict', orcout_dict)

    return orcout_dict


def remove_numchar(text, regexs, context_id):
    # Remove numbers and special characters from a text
    '''
    param: text: input text in string format
    return: text: processed text
    '''
    if context_id != 0 and entity_mode == 'ANY':
        text = replace_entity(text, regexs, context_id)
    else:
        text = replace_entity_seq(text, regexs, context_id)
    text = re.sub('[^A-Za-z]+', ' ', text)
    return text


# In[167]:


def rmv_stopwords(text, stop_words):
    # Remove stop words from a text
    '''
    param: text: input text in string format
    param: stop_words: A list of stop words
    return: text without stop words
    '''
    words = text.split()
    wordnew = [word for word in words if word not in stop_words]
    return ' '.join(wordnew)


# In[168]:


def spell_replace(text, vocab_to_int):
    words = text.split()
    # print('words', words)
    wordsnew = [spcor.corrections(word) if word not in vocab_to_int.keys() else word for word in words]
    return ' '.join(wordsnew)


# In[169]:




# Summary Data Cleaning function
def clean_data(text, prerep_dict, postrep_dict, stop_words, regexs, context_id):
    text = replace_words(text, prerep_dict)
    #text = pre_processing(text, context_id)
    # print(text)
    text = remove_numchar(text, regexs, context_id)
    # print(text)
    text = text_transform(text)
    # print(text)
    text = replace_words(text, postrep_dict)
    # print(text)
    text = rmv_stopwords(text, stop_words)
    # print(text)
    text = spell_replace(text, vocab_to_int)
    # print(text)
    text = replace_words(text, postrep_dict)
    print(text)
    #exit(0)
    return text


# In[170]:


def find_unknowns(text, vocab_to_int, prerep_dict, postrep_dict, stop_words, regexs, context_id):
    # Return count of unknown words in a text
    '''
    param: text: input text in string format
    return: # of unknown words in the text
    '''
    unk_count = 0
    text = clean_data(text, prerep_dict, postrep_dict, stop_words, regexs, context_id)
    for word in text.split():
        if (word not in vocab_to_int.keys()):
            unk_count += 1

    return unk_count


# Vectorization

# In[171]:


def create_test_utter_vectors(test_utter, vocab_size, vocab_to_int, prerep_dict, postrep_dict, stop_words, regexs,
                              context_id):
    # Create a one item dict for the test utterance that is one hot encoded
    '''
    param: test_utter: utterance that is provided for prediction
    param: vocab_size: the size of the vocabulary from pickled file
    param: vocab_to_int: dictionary from vocabulary to integer id
    param: prerep_dict: Dictionary with words to be replaced before lower case conversion
    param: prerep_dict: Dictionary with words to be replaced after lower case conversion
    param: stop_words: List of stop words
    return: dictionary with one hot encoded vector for the test utterance
    '''
    utter_test_id = 0
    unk_count = 0
    utter_dict_test = {}
    layer_0 = [0] * vocab_size
    # print(test_utter)
    sent = clean_data(test_utter, prerep_dict, postrep_dict, stop_words, regexs, context_id)
    # print(sent)
    for word in sent.split():
        if (word in vocab_to_int.keys()):
            layer_0[vocab_to_int[word]] = 1
    utter_dict_test[utter_test_id] = layer_0
    # print(utter_dict_test)
    return utter_dict_test


# In[172]:


def create_array(utter_dict):
    # Convert utter dict test to a numpy array(1D)
    '''
    param: feat_vect Dictionary with key = id of utterance and value a bag of words list for the utterance
    return: Numpy array for performing utterance match
    < This is reused from query assistant >
    '''
    keytrain_list = []
    Xtrain_list = []

    for key, value in utter_dict.items():
        keytrain_list.append(key)
        Xtrain_list.append(utter_dict[key])
        utter_array_test = np.array(Xtrain_list).astype(int)
        utter_array_test_id = np.array(keytrain_list)
    # print(utter_array_test)
    return utter_array_test, utter_array_test_id


# In[173]:


# Summary vectorizer function
def vectorizer(test_utter, vocab_size, vocab_to_int, prerep_dict, postrep_dict, stop_words, regexs, context_id):
    utter_dict_test = create_test_utter_vectors(test_utter, vocab_size, vocab_to_int, prerep_dict, postrep_dict,
                                                stop_words,
                                                regexs, context_id)
    utter_array_test, _ = create_array(utter_dict_test)
    # print(utter_array_test)
    return utter_array_test


# Prediction

# In[174]:


def create_similarity_table(utter_array_test, utter_array):
    # Create a list containing cosine similarities of the test utterance with consolidated utterances
    '''
    param: utter_array_test: test utterance provided as a one hot encoded numpy array
    return: a list containing cosine similarities of the test utterance to each utterance in the utterances repository
    '''
    # print(utter_array)
    sim = [cosine_similarity(utter_array_test.reshape(1, -1), utrep.reshape(1, -1))[0][0] for utrep in utter_array]
    # print(sim)
    return sim


# In[175]:


# FOR TESTING PURPOSES ONLY
def verify_similarity(test_utter):
    utter_array_test = vectorizer(test_utter, vocab_size, vocab_to_int, prerep_dict, postrep_dict, stop_words, regexs,
                                  context_id)
    sim = create_similarity_table(utter_array_test, utter_array)
    utterances['similarity'] = np.asarray(sim) * 100
    # print(utterances)
    utt_maxbyintent = utterances.groupby('intent_id')['similarity'].max()
    for key, row in intents.iterrows():
        intents.loc[key, 'similarity'] = utt_maxbyintent.get(row['intent_id'], 0)
    # print(intents)
    # max_intent = intents['similarity'].max()
    return intents


# In[176]:


def intents_best_match(sim, utterances, intents, unk_count, context_id):
    # Find the best matching intent id along with confidence score(out of 100)
    '''
    param: sim: list of cosine similarities
    param: utter_array_test: Test utterance in a numpy array
    param: unk_count: Count of unknown words in the utterance
    return: intent_id_best:  The closest matching intent
    return: confidence: Confidence score for the intent
    '''
    utterances['similarity'] = np.asarray(sim) * 100
    # To distinguish parent vs child
    intents_subset = intents[intents['parent_id'] == context_id]
    intents_subset = list(intents_subset['intent_id'])
    utterances_subset = utterances[utterances['intent_id'].isin(intents_subset)]
    #print(utterances_subset)
    utt_maxbyintent = utterances_subset.groupby('intent_id')['similarity'].max()
    #print(utt_maxbyintent)
    for key, row in intents.iterrows():
        #print(intents)
        intents.loc[key, 'similarity'] = utt_maxbyintent.get(row['intent_id'], 0)

    intent_max = intents['similarity'].max()
    #print(intent_max)
    #print(unk_count)
    confidence = intent_max * (0.5 ** unk_count)
    intent_id_best = intents['intent_id'][intents['similarity'].idxmax()] if confidence > threshold else unknown_intent
    #print(intent_id_best, confidence, context_id)
    return intent_id_best, confidence, context_id


# In[177]:


def response_update(response, from_orc, input_param):
    # Update a stored response based on inputs received from Oracle
    '''
    param:  response: the existing response
    param:  from_orc: the input text received from orc
    param:  param:  the param format taken from intents file for the entity
    return: response: updated response
    '''
    from_orc_dict = json.loads(from_orc)
    for item in input_param.split(';'):
        response = response.replace(item, from_orc_dict.get(item, 'unknown'))
    # print(response)
    return response


# Response best match:
# - Find response associated with best intent id
# - If input code is OQS or OQF, get the input parameters from Oracle and update the response with Oracle output
# - Get output code corresponding to the intent id
# - If output code is RC, then retain context, else reset context to 0

# In[178]:


def response_best_match(intent_id_best, intents, context_id, from_orc, input_code, input_text):
    # Find the intent and response corresponding to the best match utterance
    '''
    param: intent_id_best: The best match intent id
    return: the closest matching response from the intents dataframe
    '''
    # COMMON SECTION / DIRECT RESPONSE
    # Response Output
    response = intents['Response'][intents['intent_id'] == intent_id_best].values[0]
    input_param = intents['input_param'][intents['intent_id'] == intent_id_best].values[0]
    #print(input_param)
    if input_param !=0:
        #print("yes")
        response = response_update(response, from_orc, input_param)

    output_code = intents['output_code'][intents['intent_id'] == intent_id_best].values[0]
    to_orc = 0
    context_id = 0

    # SCENARIO SPECIFIC DEVIATIONS

    # ORACLE QUERY BASED RESPONSE
    if intents['sc_type'][intents['intent_id'] == intent_id_best].values[0] == 'OQ':

        # If context must be retained, context is parent id if non-zero else intentid (for master responses)
        if intents['retain_context'][intents['intent_id'] == intent_id_best].values[0] == 1:
            parent = intents['parent_id'][intents['intent_id'] == intent_id_best].values[0]
            context_id = parent if parent != 0 else intent_id_best

        # To orc is populated with the transaction number only if to_orc flag is 1 for the intent
        if intents['to_orc'][intents['intent_id'] == intent_id_best].values[0] == 1:
            if entity_mode == 'SQ':  # v1.6 entity sequence change
                to_orc = find_entity_seq(input_text, regexs, context_id)
            else:
                to_orc = find_entity(input_text, regexs, context_id)

    # ORACLE QUERY BASED RESPONSE
    if intents['sc_type'][intents['intent_id'] == intent_id_best].values[0] == 'XX':
        #print("XX")
        # If context must be retained, context is parent id if non-zero else intentid (for master responses)
        if intents['retain_context'][intents['intent_id'] == intent_id_best].values[0] == 1:
            parent = intents['parent_id'][intents['intent_id'] == intent_id_best].values[0]
            context_id = intent_id_best

        # To orc is populated with the transaction number only if to_orc flag is 1 for the intent
        if intents['to_orc'][intents['intent_id'] == intent_id_best].values[0] == 1:
            if entity_mode == 'SQ':  # v1.6 entity sequence change
                #print("yes")
                to_orc = find_entity_seq(input_text, regexs, context_id)
            else:
                # print("yes")
                to_orc = find_entity(input_text, regexs, context_id)

    # ORACLE Action
    if intents['sc_type'][intents['intent_id'] == intent_id_best].values[0] == 'OA':

        # If context must be retained, context is parent id if non-zero else intentid (for master responses)
        if intents['retain_context'][intents['intent_id'] == intent_id_best].values[0] == 1:
            parent = intents['parent_id'][intents['intent_id'] == intent_id_best].values[0]
            context_id = parent if parent != 0 else intent_id_best
        # To orc is populated with the transaction number only if to_orc flag is 1 for the intent
        if intents['to_orc'][intents['intent_id'] == intent_id_best].values[0] == 1:
            if entity_mode == 'SQ':  # v1.6 entity sequence change

                to_orc = find_entity_seq(input_text, regexs, context_id)
            else:

                to_orc = find_entity(input_text, regexs, context_id)

    return response, output_code, intent_id_best, context_id, to_orc


# ### Final Prediction

# In[179]:


# #### Question Response
# - Receive test_utter - a test question
# - Convert to test_utter_vectors - the question converted into a vector based on vocab as a bag of words
# - Use cosine simlarity to get a list of similarities - test vector to utterance library vectors
# - Find the count of unknown words - to calculate confidence score
# - Find the best match intent
# - Find the response corresponding to the matching intent
def pred(test_utter, vocab_size, vocab_to_int, utter_array, intents, context_id, from_orc, input_code, regexs):
    '''
    Final function for prediction combining previous functions
    param: please refer to previous parameter descriptions
    return: the response
    '''
    utter_array_test = vectorizer(test_utter, vocab_size, vocab_to_int, prerep_dict, postrep_dict, stop_words, regexs,
                                  context_id)
    # print(utter_array_test)
    sim = create_similarity_table(utter_array_test, utter_array)
    unk_count = find_unknowns(test_utter, vocab_to_int, prerep_dict, postrep_dict, stop_words, regexs, context_id)
    intent_id_best, confidence, context_id = intents_best_match(sim, utterances, intents, unk_count, context_id)
    response, output_code, intent_id_best, context_id, to_orc = response_best_match(intent_id_best, intents, context_id,
                                                                                    from_orc, input_code, test_utter)
    return response, confidence, output_code, intent_id_best, context_id, to_orc


# In[180]:


def chat(input_text, context_id, input_code, from_orc):
    '''
    param: test utterance text
    return: chat response
    '''
    response, confidence, output_code, intent_id_best, context_id, to_orc = pred(input_text, vocab_size, vocab_to_int,
                                                                                 utter_array, intents, context_id,
                                                                                 from_orc,
                                                                                 input_code, regexs)

    # v1.5: If parent response is CHD, then perform 1 child iteration
    if output_code == 'CHD':
        response = input_text + ' ' + response
        # print(response)
        response, confidence, output_code, intent_id_best, context_id, to_orc = pred(response, vocab_size, vocab_to_int,
                                                                                     utter_array, intents, context_id,
                                                                                     from_orc, input_code, regexs)
    intent_id_best = pd.Series(intent_id_best).to_json(orient='values')
    context_id = pd.Series(context_id).to_json(orient='values')
    json_response = json.dumps({'response': response,
                                'confidence': confidence,
                                'output_code': output_code,
                                'intent_id_best': intent_id_best,
                                'context_id': context_id,
                                'to_orc': to_orc
                                })

    return json_response


#print(chat('KA search',0, 'R',0))