
# coding: utf-8

# In[ ]:

### Preprocess Data


# In[110]:

import pandas as pd
import numpy as np
import re
import pickle


# Load data block

# In[111]:

# Provide csv files for utterances, intents, vocabulary, pre and post word replacements
utterances_file = 'utter.csv'
intents_file = 'intents.csv'
vocab_file = 'vocab.csv'
stopwords_file = 'stop_words.csv'
prerepdict_file = 'prerepdict.csv'
postrepdict_file = 'postrepdict.csv'
regex_file = 'regexs.csv'


# In[112]:

def load_df(utterances_file, intents_file, vocab_file, regex_file):
    # Load utterances, intents, regex and vocabulary csv files into dataframes

    '''
    param:  utterances_file : utterances csv file
    param:  intents_file : intents csv file
    param:  vocab_file: vocab csv file
    param: regex_file: regexs csv file
    return: utterances, intents, vocab, regexs : 1 pandas dataframe for each of the inputs
    '''    
    utterances = pd.read_csv(utterances_file)
    intents = pd.read_csv(intents_file)
    vocab = pd.read_csv(vocab_file)
    regexs = pd.read_csv(regex_file)
    return utterances, intents, vocab, regexs


# In[113]:

def vocab_lookups(vocab):
    # Convert vocab dataframe to vocab to int and int to vocab dictionaries
    '''
    param:  vocab : vocab pandas dataframe
    return: vocab_to_int: dictionary mapping vocabulary to id
    #return: int_to_vocab: inverse dictionary of vocab_to_int -Not required as of now
    return: vocab_size: length of vocab
    '''
    vocab_to_int = {row['word']: row['vocab_id'] for idx,row in vocab.iterrows()}
    #int_to_vocab = {value:key for key,value in vocab_to_int.items()}
    vocab_size = len(vocab_to_int)

    return vocab_to_int, vocab_size


# In[114]:

def create_stopwords(file):
    '''
    param:  file: curated csv file containing stop words. id in 1st column and 'word' in 2nd column
    return: stop_words: list of stop words
    '''
    stop_words = pd.read_csv(file)
    stop_words = list(stop_words['word'])
    return stop_words


# In[115]:

def load_replacedict(repdict_file):
    # A csv with Word and Replacement words loaded into a dictionary
    '''
    param: repdict_file: csv file with column 'Word' having words and column 'Replacement' having replacements
    return: the csv file loaded as a dictionary
    '''
    rep = pd.read_csv(repdict_file)
    rep_dict = {row['Word']: row['Replacement'] for idx,row in rep.iterrows()}
    return rep_dict


# In[116]:

# Summary Load Data function
def load_data(utterances_file, intents_file, vocab_file, stopwords_file, prerepdict_file, postrepdict_file, regex_file):
    utterances, intents, vocab, regexs = load_df(utterances_file, intents_file, vocab_file, regex_file)
    vocab_to_int, vocab_size = vocab_lookups(vocab)
    stop_words = create_stopwords(stopwords_file)
    prerep_dict = load_replacedict(prerepdict_file)
    postrep_dict = load_replacedict(postrepdict_file)
    return utterances, intents, vocab, vocab_to_int, vocab_size, stop_words, prerep_dict, postrep_dict, regexs


# Data Cleaning Block
# (Used inside Vectorizer block)

# In[117]:

def replace_words(text, replace_dict):
    # In a text, replace 'from word' to 'to word' based on a dictionary
    '''
    param: text: text within which some words have to be replaced
    param: replace_dict: dictionary that has the from and to words
    return: text: text with words replaced
    '''
    for word, replacement in replace_dict.items():
        text = text.replace(word + ' ',replacement + ' ')
        if text.endswith(word):
            text = text.replace(word,replacement + ' ') # words at the end of the string need not be followed by space
    return text


# In[118]:

def text_transform(text):
    # Strip additional spaces and convert to lower case
    '''
    param:  text: input text in string format
    return: text: processed text
    '''
    text = text.lower()
    text = re.sub('\s+',' ', text)
    return text


# In[119]:

def remove_num(text):
    # Remove numbers and special characters from a text
    '''
    param: text: input text in string format
    return: text: processed text
    '''
    text = re.sub('[^A-Za-z]+', ' ', text)
    return text


# In[120]:

def rmv_stopwords(text, stop_words):
    # Remove stop words from a text
    '''
    param: text: input text in string format
    param: stop_words: A list of stop words
    return: text without stop words
    '''
    words = text.split(' ')
    wordnew = [ word for word in words if word not in stop_words]
    return ' '.join(wordnew)


# In[121]:

# Summary Data Cleaning function
def clean_data(text, prerep_dict, postrep_dict, stop_words):
    text = remove_num(text)
    text = replace_words(text, prerep_dict)
    text = text_transform(text)
    text = replace_words(text, postrep_dict)
    text = rmv_stopwords(text, stop_words)
    return text


# Vectorization block

# In[122]:

def create_utter_vectors(utterances, vocab_size, vocab_to_int, clean_data, prerep_dict, postrep_dict, stop_words):
    # Clean and Convert utterances into a dictionary of one hot encoded vectors based on the vocabulary
    '''
    param: utterances: utterances dataframe
    param: vocab_size: vocab size
    param: vocab_to_int: vocab to int dictionary
    return: utter_dict: a dictionary with key as utterance id and value a one hot encoded vector of the utterance
    '''


    utter_dict={}
    for idx,row in utterances.iterrows():
        layer_0 = [0] * vocab_size
        sent = row['Utterance']
        sent = clean_data(sent, prerep_dict, postrep_dict, stop_words)
        #print(sent)
        for word in sent.split():
            if (word in vocab_to_int.keys()):
                layer_0[vocab_to_int[word]]=1
        utter_dict[row['utter_id']]= layer_0

    return utter_dict


# In[123]:

def create_array(utter_dict):
    # Convert dictionary of utterance vectors to a numpy array
    '''
    param: feat_vect Dictionary with key = id of utterance and value a bag of words list for the utterance
    return: Numpy array for performing utterance match
    < This is reused from query assistant >
    '''
    keytrain_list = []
    Xtrain_list = []

    for key, value in utter_dict.items():
        keytrain_list.append(key)
        Xtrain_list.append(utter_dict[key])

        utter_array = np.array(Xtrain_list).astype(int)
        utterid_array = np.array(keytrain_list)

    return utter_array,utterid_array


# In[124]:

# Summary vectorizer function
def vectorizer(utterances, vocab_size, vocab_to_int, clean_data, prerep_dict, postrep_dict, stop_words):
    
    utter_dict = create_utter_vectors(utterances, vocab_size, vocab_to_int, clean_data, prerep_dict, 
                                      postrep_dict, stop_words)
    utter_array, utterid_array = create_array(utter_dict)
    #print(utter_array)
    return utter_array, utterid_array


# ### MAIN SECTION
# Preprocess the data and pickle it

# In[125]:

utterances,intents, vocab, vocab_to_int, vocab_size,stop_words,prerep_dict,postrep_dict, regexs = load_data( utterances_file, 
                                                                                                       intents_file, 
                                                                                                       vocab_file, 
                                                                                                       stopwords_file,
                                                                                                       prerepdict_file,
                                                                                                       postrepdict_file,
                                                                                                           regex_file)


utter_array , utterid_array = vectorizer(utterances, vocab_size, vocab_to_int, clean_data, prerep_dict, postrep_dict, 
                                         stop_words)


# In[126]:

with open('chat_pkl.pkl', 'wb') as f:
    pickle.dump((utter_array,utterid_array,utterances,intents,vocab,vocab_to_int,vocab_size,stop_words, prerep_dict, 
                 postrep_dict, regexs),f)










