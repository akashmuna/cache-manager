# Orro allows you to chat with your Oracle Retail application to retrieve information.
from flask import Flask,request# ## ORRO CHATBOT
import chat_api_help as cah
from chat_api_help import chat as chat
from flask_cors import CORS, cross_origin
import json
import pandas as  pd

###Creating WSGI(Web Server Gateway Interface)###
app = Flask(__name__)
app.config['CORS_HEADERS'] = 'Content-Type'
cors = CORS(app, resources={r"/post": {"origins": "http://192.168.43.151:5100"}})


@app.route('/chatbot',methods=['GET']) # the endpoint
@cross_origin(origin='*',headers=['Content- Type','Authorization'])

def chatbot():

        input_text=request.args.get('input_text',type = str)
        context_id=request.args.get('context_id',type = int )
        input_code=request.args.get('input_code',type= str)
        from_orc=request.args.get('from_orc',type = str)

        from_orc_new= json.loads(from_orc.replace("\'",'"'))

        json_response=( chat(input_text, context_id, input_code, from_orc_new))

        return json_response


if __name__ == '__main__':
    app.run(host='192.168.43.151', port=5100, debug=False)

