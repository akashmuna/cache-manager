import pickle

with open('spellchecker.pkl','rb') as f:
        wordcounts,probs = pickle.load(f)

##Cleaning the wordcounts dictionary
entriestoremove = ('ordre','mot','holmes', 'watson')
for k in entriestoremove:
    wordcounts.pop(k, None)

def get_prob(word, wordcounts = wordcounts): return wordcounts.get(word,0) / sum(wordcounts.values())

def edits1(word):
    '''
    param: word : The input word
    return:
    '''
    letters = 'abcdefghijklmnopqrstuvwxyz'
    splits = [(word[:i],word[i:])for i in range(len(word)+1)]
    deletes = [L + R[1:] for L,R in splits if R]
    transposes = [L + R[1] + R[0] + R[2:] for L,R in splits if len(R)>1]
    replaces = [L + c + R[1:] for L,R in splits if R for c in letters]
    inserts = [L + c + R for L,R in splits for c in letters]
    return(set( deletes + transposes + replaces + inserts))

def edits2(word): return (e2 for e1 in edits1(word) for e2 in edits1(e1))

def known(words): return set(w for w in words if w in wordcounts)
def candidates(word):
    return (known([word]) or known(edits1(word)) or known(edits2(word)) or [word] )

def corrections(word):
    if word not in wordcounts:
        #print(word,' is not present in wordcounts dictionary')
        #print("Candidate Words are", candidates(word))
        #print('Candidate Word with max probability is returned i.e.',max(candidates(word), key = get_prob))
        correct_word = max(candidates(word), key = get_prob)
        #print('correct word', correct_word)
        return correct_word
    else:
        #print(word,' exists in Wordcount Dictionary so spell check not performed')
        return word



