
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import re
from collections import Counter


utterances_file = 'utter.csv'
stopwords_file = 'stop_words.csv'
prerepdict_file = 'prerepdict.csv'
postrepdict_file = 'postrepdict.csv'


# In[3]:

def create_stopwords(file):
    '''
    param:  file: curated csv file containing stop words. id in 1st column and 'word' in 2nd column
    return: stop_words: list of stop words
    '''
    stop_words = pd.read_csv(file)
    stop_words = list(stop_words['word'])
    return stop_words


# In[4]:

def load_replacedict(repdict_file):
    # A csv with Word and Replacement words loaded into a dictionary
    '''
    param: repdict_file: csv file with column 'Word' having words and column 'Replacement' having replacements
    return: the csv file loaded as a dictionary
    '''
    rep = pd.read_csv(repdict_file)
    rep_dict = {row['Word']: row['Replacement'] for idx,row in rep.iterrows()}
    return rep_dict


# In[5]:

# Summary Load Data function
def load_data(utterances_file,stopwords_file, prerepdict_file, postrepdict_file):
    utterances = pd.read_csv(utterances_file)
    stop_words = create_stopwords(stopwords_file)
    prerep_dict = load_replacedict(prerepdict_file)
    postrep_dict = load_replacedict(postrepdict_file)
    return utterances, stop_words, prerep_dict, postrep_dict
    


# In[6]:

utterances, stop_words, prerep_dict, postrep_dict = load_data(utterances_file, stopwords_file, prerepdict_file, 
                                                                postrepdict_file)


# #### Data Cleaning

# In[7]:

text=""
for idx,row in utterances.iterrows():
    text = text + ' ' + row['Utterance'] 


# In[8]:

def replace_words(text, replace_dict):
    # In a text, replace 'from word' to 'to word' based on a dictionary
    '''
    param: text: text within which some words have to be replaced
    param: replace_dict: dictionary that has the from and to words
    return: text: text with words replaced
    '''
    for word, replacement in replace_dict.items():
        text = text.replace(word + ' ',replacement + ' ')
        if text.endswith(word):
            text = text.replace(word,replacement + ' ') # words at the end of the string need not be followed by space
    return text

def text_transform(text):
    # Strip additional spaces and convert to lower case
    '''
    param:  text: input text in string format
    return: text: processed text
    '''
    text = text.lower()
    text = re.sub('\s+',' ', text)
    return text

def remove_num(text):
    # Remove numbers and special characters from a text
    '''
    param: text: input text in string format
    return: text: processed text
    '''
    text = re.sub('[^A-Za-z]+', ' ', text)
    return text

def rmv_stopwords(text, stop_words):
    # Remove stop words from a text
    '''
    param: text: input text in string format
    param: stop_words: A list of stop words
    return: text without stop words
    '''
    words = text.split(' ')
    wordnew = [ word for word in words if word not in stop_words]
    return ' '.join(wordnew)

# Summary Data Cleaning function
def clean_data(text, prerep_dict, postrep_dict, stop_words):
    text = remove_num(text)
    text = replace_words(text, prerep_dict)
    text = text_transform(text)
    text = replace_words(text, postrep_dict)
    text = rmv_stopwords(text, stop_words)
    return text


# In[9]:

text = clean_data(text, prerep_dict, postrep_dict, stop_words)


# #### Generate Vocabulary

# In[10]:

def gen_vocab(text):
    text = re.findall(r'\w+',text.lower())
    vocab_raw = {key:value for key,value in enumerate(set(text))}
    return vocab_raw


# In[11]:

vocab_dict = gen_vocab(text)
vocab = pd.DataFrame(list(vocab_dict.items()), columns= ['vocab_id', 'word'])


# In[12]:

vocab.to_csv('vocab.csv', index = False)


# In[ ]:




# In[ ]:



